# Nguồn của agent `agency-healthcare-clinical-evidence-agent`

Một agent lẻ của gói `tisa.agency-agents`, lấy từ [msitarzewski/agency-agents/healthcare/healthcare-clinical-evidence-agent.md](https://github.com/msitarzewski/agency-agents/blob/main/healthcare/healthcare-clinical-evidence-agent.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho TISA (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, TISA báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
