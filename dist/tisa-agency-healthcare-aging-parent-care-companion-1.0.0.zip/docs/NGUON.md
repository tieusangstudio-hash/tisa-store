# Nguồn của agent `agency-healthcare-aging-parent-care-companion`

Một agent lẻ của gói `tisa.agency-agents`, lấy từ [msitarzewski/agency-agents/specialized/healthcare-aging-parent-care-companion.md](https://github.com/msitarzewski/agency-agents/blob/main/specialized/healthcare-aging-parent-care-companion.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho TISA (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, TISA báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
